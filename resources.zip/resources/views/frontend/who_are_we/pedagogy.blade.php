@extends('frontend.templates.app')

@section('content')
    <div class="container mt-4">
        {!! $pedagogy->description !!}
    </div>
@endsection