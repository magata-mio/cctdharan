@extends('frontend.templates.app')
@section('content')
    <div class="container">
        
    </div>
@endsection