 {{-- Carousel --}}
 {{-- <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-inner" style="max-height: 90vh">
      <div class="carousel-item active" style="max-height: 90vh">
        <img src="{{ asset('img/s3.jpg') }}" class="w-100" alt="..." style="max-height: 90vh">
      </div>
      <div class="carousel-item" style="max-height: 90vh">
        <img src="{{ asset('img/s6.jpg') }}" class="w-100" alt="..." style="max-height: 90vh">
      </div>
      
      
      <div class="carousel-item" style="max-height: 90vh">
        <img src="{{ asset('img/s2.jpg') }}" class="w-100" alt="..." style="max-height: 90vh">
      </div>
      <div class="carousel-item" style="max-height: 90vh">
        <img src="{{ asset('img/s1.jpg') }}" class="w-100" alt="..." style="max-height: 90vh">
      </div>
      
      

      <div class="carousel-item">
        <img src="{{ asset('img/s4.jpg') }}" class="w-100" alt="..." style="max-height: 90vh">
      </div>
      <div class="carousel-item">
        <img src="{{ asset('img/s5.jpg') }}" class="w-100" alt="..." style="max-height: 90vh">
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </a>
</div> --}}

 <!-- BANNER -->
 <div class="container-fluid" style="height: 550px; max-height:50vh; background-image: url(/img/Campus\ view.jpg);background-size:cover;background-position:bottom;">
        
 </div>