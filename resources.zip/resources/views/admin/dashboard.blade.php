@extends('admin.templates.app')

@section('info')
    @include('admin.include.info')
@endsection

@section('content')
    
@endsection